require('dotenv').config();
require('express-async-errors');

const helmet = require('helmet');
const cors = require('cors');
const xss = require('xss-clean');
const rateLimiter = require('express-rate-limit');
const swaggerUi = require('swagger-ui-express');
const YAML = require('yamljs');
const swaggerDocument = YAML.load('./swagger.yaml');
const express = require('express');
const Sentry = require('@sentry/node');
const Tracing = require('@sentry/tracing');

const app = express();
const connectDB = require('./db/connectdb');
const authenticateUser = require('./middleware/authenticateUser');
const auth = require('./routes/auth');
const users = require('./routes/users');
const payment = require('./routes/payment');
const property = require('./routes/property');
const notFoundMiddleware = require('./middleware/not-found');
const errorHandlerMiddleware = require('./middleware/error-handler');

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  integrations: [
    new Sentry.Integrations.Http({ tracing: true }),
  ],
  tracesSampleRate: 1.0,});

app.use(Sentry.Handlers.requestHandler());
app.use(Sentry.Handlers.tracingHandler());

app.set('trust proxy', 1);
app.use(
  rateLimiter({
    windowMs: 15 * 60 * 1000,
    max: 100,
  })
);
app.use(express.json());
app.use(helmet());
app.use(cors({ origin: '*' }));
app.use(xss());

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.get('/', (req, res) => {
  res.send('<h1>Charis Api is live</h1><a href="/api-docs">API Documentation</a>');
});

app.use('/api/v1/auth', auth);
app.use('/api/v1/users', authenticateUser, users);
app.use('/api/v1/payment', authenticateUser, payment);
app.use('/api/v1/property', property);

app.use(Sentry.Handlers.errorHandler());

app.use(notFoundMiddleware);
app.use(errorHandlerMiddleware);



const port = process.env.PORT || 3000;

const start = async () => {
  try {
    await connectDB(process.env.MONGO_URL);
    app.listen(port, () => console.log(`server is listening on ${port}...`));
  } catch (error) {
    console.error(error);
  }
};

start();
