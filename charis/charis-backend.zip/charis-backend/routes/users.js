const express = require('express')
const router = express.Router()
const upload = require('../middleware/upload')


const {showAllUser, showSingleUser, showUserByStatus, editUser, regAsAffiliate, showAllAffiliates, calculateShareCapital, editUserUnstructured, reqWithdrawal, getAllWithdrawals, getAllPendingWithdrawals, approveOrDeclineReq, calculateROI, getAllMyWithdrawals,checkLoanEligibility, uploadImage} = require('../controllers/users')

router.route('/').get(showAllUser)
router.route('/:id').get(showSingleUser)
router.get('/status/both', showUserByStatus)
router.patch('/:id', editUser)
router.route('/affiliates/reg').patch(regAsAffiliate)
router.route('/affiliates/showAll').get(showAllAffiliates)
router.route('/shareCapital').post(calculateShareCapital)
router.route('/editUserUnstructured/:id').patch(editUserUnstructured)
router.route('/dashboard/withdrawal').post(reqWithdrawal).get(getAllWithdrawals)
router.route('/withdrawal/pending').get(getAllPendingWithdrawals)
router.route('/dashboard/withdrawal/:id').patch(approveOrDeclineReq)
router.route('/dashboard/shareCapital/roi').post(calculateROI)
router.route('/withdrawal/mine').get(getAllMyWithdrawals)
router.route('/loan/checkLoanEligibility').get(checkLoanEligibility)
router.patch('/image/upload', upload.single('file'), uploadImage)


module.exports = router