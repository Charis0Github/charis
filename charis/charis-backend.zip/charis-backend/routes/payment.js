const express = require('express')
const router = express.Router()



const {createPaymentLink, verifyPayment, myPaymentHistory, allPayments, singlePayment} = require('../controllers/payment')

router.route('/').post(createPaymentLink)
router.post('/verify', verifyPayment)
router.route('/:id').get(myPaymentHistory)
router.route('/single/:id').get(singlePayment)
router.route('/users/all').get(allPayments)




module.exports = router