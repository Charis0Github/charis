const express = require('express')
const router = express.Router()
const upload = require('../middleware/upload')


const {createProperty, editProperty, showAllProperties, removeProperty, showSingleProperty, showApprovedProperties} = require('../controllers/property')

router.route('/').get(showAllProperties).post(upload.single('file'), createProperty)
router.route('/all/approved').get(showApprovedProperties)
router.route('/:id').get(showSingleProperty).patch(editProperty).delete(removeProperty)


module.exports = router