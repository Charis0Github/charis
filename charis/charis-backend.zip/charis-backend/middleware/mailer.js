const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: 'smtp.titan.email',
  port: 465,
  secure: true,
  auth: {
    user: process.env.EMAIL_USERNAME,
    pass: process.env.EMAIL_PASSWORD,
  },
});

const sendEmail = (to, subject, html, callback) => {
  const mailOptions = {
    from: 'reg@calgi.org',
    to: to,
    subject: subject,
    html: html,
  };

  try {
    transporter.sendMail(mailOptions, (error, info) => {
    
      if (callback && typeof callback === 'function') {
        callback(error, info);
      }
      
    });
  } catch (error){
     console.log(error)
  }
}
  
module.exports = sendEmail
