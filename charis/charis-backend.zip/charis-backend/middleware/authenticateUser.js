const jwt = require("jsonwebtoken");
const { StatusCodes } = require("http-status-codes");
const { UnauthenticatedError } = require("../errors");

const authenticateUser = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      throw new UnauthenticatedError("Invalid Authentication");
    }
    const token = authHeader.split(" ")[1];

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = extractUserFields(decoded);
    next();
  } catch (error) {
    res.status(StatusCodes.UNAUTHORIZED).send({ msg: error.message });
  }
};

const extractUserFields = (decoded) => {
  const userFields = [
    "email",
    "userid",
    "role",
    "name",
    "title",
    "nationality",
    "gender",
    "lga",
    "address",
    "profession",
    "officeAddress",
    "statusRank",
    "monthlyIncome",
    "yearsOfService",
    "retirementAge",
    "educationalQualification",
    "nextOfKinName",
    "nextOfKinAddress",
    "nextOfKinPhoneNumber",
    "relationship",
    "nextOfKinEmail",
    "houseType",
    "houseSize",
    "preferredLocation",
    "paymentPlan",
    "paymentPlanId",
    "date",
    "createdAt",
    "status",
    "phoneNumber",
    "imageLink",
    "dueDate",
    "resetPasswordToken",
    "resetPasswordExpire",
    "affiliateUserName",
    "myRefCode",
    "balance",
    "paidRefs",
    "unpaidRefs",
    "withdrawn",
    "savings",
    "shoppingPoints",
    "houseAmount",
    "spread",
    "monthlyHousePayment",
    "shareCapital",
    "houseMembershipStatus",
    "dob",
    "shareCapitalStatus",
    "savingsDueDate",
    "houseTarget",
    "housePayment",
    "dateInvested",
    "investmentDueDate",
    "investmentAmount",
    "roi",
    "dateRegistered",
    "bank",
    "accountNumber",
    "monthlyHousePaymentDub",
    "housePaymentDub",
    "shareCapitalAmount",
    "monthlyPaymentSoFar",
    "investSpread",
    "shareCapitalLeft",
    "referee" 
  ];

  return userFields.reduce((user, field) => {
    if (decoded[field] !== undefined) {
      user[field] = decoded[field];
    }
    return user;
  }, {});
};

module.exports = authenticateUser;
