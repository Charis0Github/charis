const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
require("dotenv");

const PaymentRecordsSchema = new mongoose.Schema({
  amount: {
    type: Number,
    required: [true, "Please provide amount paid"],
  },

  datePaid: {
    type: Date,
    default: Date.now,
  },

  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Please provide a user'],
  },

  userName:{
    type:String
},

phoneNumber:{
  type:String
},

email:{
  type:String
},


  transactionId:{
    type: String,
    required: [true, 'Please provide a transaction id'],
  },

   tag:{
    type:String,
    enum:['reg', 'house', 'share', 'invest', 'savings', 'monthly'],
    required:[true, 'You need to tag your payments for event calls']
   }
  

});

module.exports = mongoose.model("PaymentRecords", PaymentRecordsSchema);
