const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
require("dotenv");

const PropertySchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Please provide a name"],
  },

  location: {
    type: String,
    required: [true, "Please provide a location"],
  },

  price: {
    type: Number,
    required: [true, "Please provide a price"],
  },

  description: {
    type: String,
    required: [true, "Please provide a description"],
  },

  status: {
    type: String,
    enum: ["approved", "sold", "pending"],
    default: "pending",
  },

  buildingFloorArea: {
    type: String,
  },

  plotSize: {
    type: String,
  },

  roomNumber: {
    type: Number,
  },

  createdAt: {
    type: Date,
    default: Date.now,
  },

  type: {
    type: String,
  },

  imageLink: {
    type: String,
  },

  
});

module.exports = mongoose.model("Property", PropertySchema);
