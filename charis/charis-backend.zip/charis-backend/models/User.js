const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
require("dotenv");

const UserSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Please provide your name"],
    minlength: [5, "Name too short"],
    maxLength: [50, "Name too long"],
    lowercase: true,
  },

  title: {
    type: String,
    lowercase: true,
  },

  nationality: {
    type: String,
    lowercase: true,
  },

  gender: {
    type: String,
    lowercase: true,
  },

  lga: {
    type: String,
    lowercase: true,
  },

  address: {
    type: String,
    lowercase: true
  },

  profession: {
    type: String,
    lowercase: true,
  },

  officeAddress: {
    type: String,
    lowercase: true,
  },

  statusRank: {
    type: String,
    lowercase: true,
  },

  monthlyIncome: {
    type: Number,
  },

  yearsOfService: {
    type: Number,
  },

  retirementAge: {
    type: Number,
  },

  educationalQualification: {
    type: String,
    lowercase: true,
  },

  nextOfKinName: {
    type: String,
    lowercase: true,
  },

  nextOfKinAddress: {
    type: String,
    lowercase: true,
  },

  nextOfKinPhoneNumber: {
    type: String,
  },

  relationship: {
    type: String,
    lowercase: true,
  },

  nextOfKinEmail: {
    type: String,
    lowercase: true,
  },

  houseType: {
    type: String,
    enum: ["flat", "bungalow", "duplex"],
    lowercase:true,
  },

  houseSize: {
    type: String,
    // enum: ["1 bedroom", "2 bedroom", "3 bedroom", "4 bedroom"],
    lowercase:true,
  },

  dob:{
    type:Date
  },

  preferredLocation: {
    type: String,
    // enum: [
    //   "Egba Layout after Auchi road bypass",
    //   "Obe Layout before Sapele Road Bypass",
    //   "Etete Layout",
    //   "Along Sapele Road",
    //   "Along Adesuwa Road",
    //   "Amufi Layout",
    //   "NPDC Layout",
    // ],
    lowercase:true,
  },

  paymentPlan: {
    type: String,
    // enum: [
    //   "50% Payment and 1 year Spread of Balance",
    //   "50% Payment and 2 years Spread of Balance",
    //   "371k & Monthly Payment for 5 to 30yrs",
    // ],
    lowercase:true,
  },

  paymentPlanId: {
    type: String,
    enum: ["1", "2", "3"],
  },

  imageLink: {
    type: String,
  },

  date: {
    type: Date,
  },

  dueDate: {
    type: Date,
    },

    dateInvested:{
      type:Date,
    },

    investmentDueDate:{
      type:Date,
    
    },

  role: {
    type: String,
    enum: ["user", "admin"],
    required: [true, "Please select a role"],
    lowercase: true,
    default: "user",
  },

  affiliateUserName: {
    type:String,
    index: true,
  },

  myRefCode:{
    type:String,
    
  },

  unpaidRefs:{
    type:Number,
    default:0
  },

  paidRefs:{
    type:Number,
    default:0
  },

  referee:{
    type:String
  },

  balance:{
    type:Number,
    default:0
  },

  withdrawn:{
    type:Number,
    default:0
  },
  
  savings:{
    type:Number,
    default:0
  },

  houseTarget:{
    type:Number,
    default:0
  },

  housePayment:{
    type:Number,
    default:0
  },
  
  shareCapitalAmount:{
    type:Number,
    default:0
  },

  shareCapitalLeft:{
    type:Number,
    default:0
  },

  shoppingPoints:{
    type:Number,
    default:0
  },


  investmentAmount:{
    type:Number,
    default:0
  },

  accountNumber:{
    type:String,
   
  },

  bank:{
    type:String,
  },

  phoneNumber: {
    type: String,
    required: [true, "Please provide your phone number"],
  },

  password: {
    type: String,
    required: [true, "Please provide your password"],
    minlength: [3, "Password must be at least 8 characters"],
  },

  email: {
    type: String,
    required: [true, "Please provide your email"],
    match: [
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
      "Please provide a valid email",
    ],
    unique: true,
  },

  status: {
    type: String,
    enum: ["paid", "not-paid"],
    required: [true, "Please select user status"],
    default: "not-paid",
  },

  houseMembershipStatus: {
    type: String,
    enum: ["paid", "not-paid"],
    required: [true, "Please select houseMemberShip status"],
    default: "not-paid",
  },

  shareCapitalStatus: {
    type: String,
    enum: ["paid", "not-paid", "part-paid"],
    required: [true, "Please select sharecapital status"],
    default: "not-paid",
  },

  savingsDueDate:{
    type:Date
  },


  houseAmount: {
    type: Number,
    default:0
  },

  spread: {
    type: Number,
    enum: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
  },

  roi:{
    type: Number,
    default:0
  },

  monthlyHousePayment: {
    type:Number,
    default:0
  },

  createdAt: {
    type: Date,
  },

  dateRegistered:{
    type:Date
  },


  investSpread:{
    type:Number
  },

  resetPasswordToken:{
    type: String,
  },

  resetPasswordExpire:{
    type: Date,
  },

  monthlyHousePaymentDub:{
    type: Number,
    default:0,
  },

  houseAmountDub:{
    type: Number,
    default:0
  },

  monthlyPaymentSoFar:{
    type:Number,
    default:0
  }
});


// Define a method for hashing the password
UserSchema.methods.hashPassword = async function (password) {
  const salt = await bcrypt.genSalt(10);
  return await bcrypt.hash(password, salt);
};

// Registration logic
UserSchema.pre('save', async function (next) {
  this.password = await this.hashPassword(this.password);
  next();
});

UserSchema.methods.createJWT = function () {
  return jwt.sign(
    {
      userid: this._id,
      role: this.role,
      name: this.name,
      email: this.email,
      phoneNumber: this.phoneNumber,
      status: this.status,
      imageLink: this.imageLink,
      createdAt: this.createdAt,
      title: this.title,
      nationality: this.nationality,
      gender: this.gender,
      lga: this.lga,
      address: this.address,
      profession: this.profession,
      officeAddress: this.officeAddress,
      statusRank: this.statusRank,
      monthlyIncome: this.monthlyIncome,
      yearsOfService: this.yearsOfService,
      retirementAge: this.retirementAge,
      educationalQualification: this.educationalQualification,
      nextOfKinName: this.nextOfKinName,
      nextOfKinAddress: this.nextOfKinAddress,
      nextOfKinPhoneNumber: this.nextOfKinPhoneNumber,
      relationship: this.relationship,
      nextOfKinEmail: this.nextOfKinEmail,
      houseType: this.houseType,
      houseSize: this.houseSize,
      preferredLocation: this.preferredLocation,
      paymentPlan: this.paymentPlan,
      paymentPlanId: this.paymentPlanId,
      date: this.date,
      dueDate: this.dueDate,
      resetPasswordToken: this.resetPasswordToken,
      resetPasswordExpire: this.resetPasswordExpire,
      affiliateUserName: this.affiliateUserName,
      myRefCode: this.myRefCode,
      unpaidRefs: this.unpaidRefs,
      paidRefs: this.paidRefs,
      balance: this.balance,
      withdrawn: this.withdrawn,
      savings: this.savings,
      shoppingPoints: this.shoppingPoints,
      houseAmount: this.houseAmount,
      spread: this.spread,
      monthlyHousePayment: this.monthlyHousePayment,
      shareCapital:this.shareCapital,
      houseMembershipStatus:this.houseMembershipStatus,
      dob:this.dob,
      shareCapitalStatus:this.shareCapitalStatus,
      savingsDueDate:this.savingsDueDate,
      houseTarget:this.houseTarget,
      housePayment:this.housePayment,
      dateInvested:this.dateInvested,
      investmentDueDate:this.investmentDueDate,
      investmentAmount:this.investmentAmount,
      roi:this.roi,
      investSpread:this.investSpread,
      dateRegistered:this.dateRegistered,
      accountNumber:this.accountNumber,
      bank:this.bank,
      monthlyHousePaymentDub:this.monthlyHousePaymentDub,
      housePaymentDub:this.housePaymentDub,
      shareCapitalAmount:this.shareCapitalAmount,
      monthlyPaymentSoFar:this.monthlyPaymentSoFar,
      shareCapitalLLeft:this.shareCapitalLeft,
      referee:this.referee,
    },
    process.env.JWT_SECRET,
    {
      expiresIn: process.env.JWT_LIFETIME,
    }
  );
};


UserSchema.methods.comparePassword = async function (loginPasword) {
  const isMatch = await bcrypt.compare(loginPasword, this.password);
  return isMatch;
};

module.exports = mongoose.model("User", UserSchema);
