const { StatusCodes } = require("http-status-codes");
const sendEmail = require('../middleware/mailer');
const Payment = require("../models/PaymentRecords");
const User = require("../models/User");
const { BadRequestError } = require("../errors");
const shortid = require("shortid");
const axios = require("axios");



  const myPaymentHistory = async (req, res) => {
    if (req.user.role === "admin") {
      req.user.userid = req.params.id
    }
    const payments = await Payment.find({ createdBy: req.user.userid }).sort({
      datePaid: "desc",
    });
    res.status(StatusCodes.OK).json({ payments });
  }

  const allPayments = async (req, res) => {
    const payments = await Payment.find({}).sort({
      datePaid: "desc",
    });
    res.status(StatusCodes.OK).json({ payments });
  }
  
  const singlePayment = async (req, res) => {
    const {
      params: { id: tx_ref },
    } = req;
    const payments = await Payment.findOne({transactionId:tx_ref}).sort({
      datePaid: "desc",
    });
    res.status(StatusCodes.OK).json({ payments });
  }

  const createPaymentLink = async (req, res) => {

    try {
      // Validate request body
      const {
        amount,
        redirect,
        tag
      } = req.body
      const currency = 'NGN'
      if (!amount || !currency) {
        throw new BadRequestError('Missing required fields')
      }
  
     
      // Generate tx_ref
      const txRef = shortid.generate()
  
  
  
      // Make request to Flutterwave API
      const response = await axios.post(
        'https://api.flutterwave.com/v3/payments', {
          tx_ref: txRef,
          amount: amount,
          currency: currency,
          redirect_url: redirect,
          meta: {
            consumer_id: req.user._id 
          },
          customer: {
            email: req.user.email,
            phonenumber: req.user.phoneNumber,
            name: req.user.name,
          },
          customizations: {
            title: 'CHARIS ADVANTAGE LGi',
            logo: '',
          },
        }, {
          headers: {
            Authorization: `Bearer ${process.env.SECRET_KEY}`,
          },
        }
      )
  
  
  
      // Send payment link in response
      res.status(StatusCodes.OK).json({
        response: response.data,
        transactionId: txRef,
        tag:tag

      })
  
  
    } catch (err) {
      console.log(err)
      
    }
      };


      const verifyPayment = async (req, res) => {
        try {
          const { transactionId, tag } = req.body;
      
          // Send a GET request to verify the transaction by reference
          const response = await axios.get(
            `https://api.flutterwave.com/v3/transactions/verify_by_reference?tx_ref=${transactionId}`,
            {
              headers: {
                Authorization: `Bearer ${process.env.SECRET_KEY}`,
              },
            }
          );
          const todayToday = Date.now()
          const email = response.data.data.customer.email;
          const amount = response.data.data.charged_amount;
          
          const userData = await User.findOne({email:email})
      
          // Check if the transaction was successful
          if (response.data.data.status === 'successful') {
            let updateOperations = {};
            let refUpdate = {};
            let userRef;
            let emailmsg;
      
            if (tag === 'reg') {
              emailmsg = '<p>Congrats on your registration as a member of the co-operative we are glad to have you on.<p>'
              if (req.user.status === 'paid') {
                console.error('User has already paid');
                return res.status(400).send('User has already paid');
              }
      
              updateOperations = {
                $set: { status: 'paid', dateRegistered: todayToday}, // Set 'status' to 'paid' and dateRegistered
              };
      
              if (req.user.referee !== undefined) {
                userRef = req.user.referee;
      
                // Update the referee's document
                refUpdate = {
                  $inc: {
                    unpaidRefs: -1, // Decrease unpaidRefs by 1
                    paidRefs: 1,    // Increase paidRefs by 1
                    balance: 2500,  // Increase balance by 2500
                  },
                };
                await User.updateOne({ myRefCode: userRef }, refUpdate);
              }
            } else if (tag === 'house') {
              emailmsg = '<p>Congrats on your house payment of #50,000, you can proceed by paying your share capital.<p>'
              if (req.user.houseMembershipStatus === 'paid') {
                console.error('User has already paid');
                return res.status(400).send('User has already paid');
              }
      
              updateOperations = {
                $set: {houseMembershipStatus: 'paid' }, // Set 'houseMembershipStatus' to 'paid'
              };
      
              if (req.user.referee !== undefined) {
                userRef = req.user.referee;
      
                refUpdate = {
                  $inc: { balance: 5000 }, // Increase balance by 5000
                };
                await User.updateOne({ myRefCode: userRef }, refUpdate);
              }
            }
            //  else if (tag === 'share') {
            //   emailmsg = '<p>Congrats on your share capital payment, you are well underway to owning your house.<p>'
            //   if (req.user.shareCapitalStatus === 'paid') {
            //     console.error('User has already paid');
            //     return res.status(400).send('User has already paid');
            //   }

            //   //const houseT = req.user.houseAmount - amount
            //   let mhp = userData.monthlyHousePaymentDub
            //   let ha = userData.houseAmountDub
             
            //   updateOperations = {
            //     $set: { shareCapitalStatus: 'paid', monthlyHousePayment:mhp, shareCapitalAmount: amount, houseAmount:ha, dueDate: Date.now() + 2592000000 }, // Set 'shareCapitalStatus' to 'paid' and update 'dueDate'
                
            //   };

              // share capital part payment
             else if (tag === 'share') {
              if (userData.shareCapitalStatus === 'paid') {
                console.error('User has already paid');
                return res.status(400).send('User has already paid');
              }

              //const houseT = req.user.houseAmount - amount
              // let mhp = userData.monthlyHousePaymentDub
              // let ha = userData.houseAmountDub
              //monthlyHousePayment:mhp
              //houseAmount:ha

              let shareCapitalLeft = userData.shareCapitalLeft - amount

              if (shareCapitalLeft <= 0 ) {
              //const houseT = req.user.houseAmount - amount
              let mhp = userData.monthlyHousePaymentDub
              let ha = userData.houseAmountDub

                updateOperations = {
                  $set: { shareCapitalStatus: 'paid', shareCapitalLeft: shareCapitalLeft, monthlyHousePayment:mhp, houseAmount:ha, dueDate: Date.now() + 2592000000}, // Set 'shareCapitalStatus' to 'paid' and update 'dueDate'
                  $inc:{shareCapitalAmount: amount} 
                };

              } else {
                updateOperations = {
                  $set: { shareCapitalStatus: 'part-paid', shareCapitalLeft: shareCapitalLeft}, // Set 'shareCapitalStatus' to 'paid' and update 'dueDate'
                  $inc:{shareCapitalAmount: amount}
                };
              }


            }else if (tag === 'savings') {
              emailmsg = '<p>Congrats on your savings payment.<p>'
              updateOperations = {
                $inc: { savings: amount }, // Increase 'savings' by 'amount'
                $set: { savingsDueDate: Date.now() + 2592000000 }, // Update 'savingsDueDate'
              };
            } else if (tag === 'monthly') {
              emailmsg = '<p>Congrats on your monthly payment keep at it, you are one step closer to your house goals<p>'
              updateOperations = {
                $inc: { monthlyPaymentSoFar: amount }, // Increase 'housePayment' and decrease 'houseTarget' by 'amount'
                $set: { dueDate: Date.now() + 2592000000 }, // Update 'dueDate'
              };
            } else if(tag === 'invest') {
              emailmsg = '<p>Congrats on your investment payment<p>'
              let roi = amount * 0.3
              // let isd = req.user.investSpread * 2592000000
              
              updateOperations = {
                $set: { dateInvested: Date.now(), roi:roi, investmentAmount: amount}, // Update 'dateInvested'
            }
          }  
            // Perform the update on the user document
            await User.updateOne({ email: email }, updateOperations);
      
            // Perform the update on the referee document if userRef is defined
           
      
            
              const paymentRecord = await Payment.create({
                createdBy: req.user.userid,
                amount: amount,
                transactionId: transactionId,
                datePaid: Date.now(),
                userName: req.user.name,
                phoneNumber:req.user.phoneNumber,
                email:req.user.email,
                tag: tag,
              });
            
      
              sendEmail(req.user.email, 'Payment Received', emailmsg, (error, info) => {
                if (error) {
                  console.error('Error sending email:', error);
                } else {
                  console.log('Email sent:', info.response);
                }
              });
              
      
            res.status(StatusCodes.OK).json({ record: paymentRecord });
          } else {
            res.status(StatusCodes.BAD_REQUEST).json('Payment Failed')
          }
        } catch (error) {
          console.error(error);
          res.status(StatusCodes.BAD_REQUEST).json(error.message);
        }
      };
      
  
      
      
  
  

module.exports = {
  myPaymentHistory, 
  allPayments,
  singlePayment,
  createPaymentLink,
  verifyPayment
};
