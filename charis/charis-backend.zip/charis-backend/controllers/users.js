const User = require("../models/User");
const Withdrawal = require("../models/Withdrawal");
const { StatusCodes } = require("http-status-codes");
const { BadRequestError, UnauthenticatedError, NotFoundError } = require("../errors");
const jwt = require("jsonwebtoken");
const shortid = require('shortid');

const editUser = async (req, res) => {
  try {
    const {
      body: changes, // Destructure the changes directly from the req.body
    } = req;

    const email = req.user.email
    


    const result = await User.updateOne(
      { email: email},
      { $set: changes }, // Use $set to update the specified fields
      { runValidators: true }
    );

    if (result.nModified === 0) {
      throw new NotFoundError("Error making changes");
    }

    res.status(StatusCodes.OK).json({ msg: "Change has been successfully made" });
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
};



const showUserByStatus = async (req, res) => {
  try {
    const users = await User.find();

    const paidUsers = users.filter(user => user.status === 'paid');
    const notPaidUsers = users.filter(user => user.status !== 'paid');

    res.status(StatusCodes.OK).json({
      paidUsers,
      notPaidUsers,
      paidCount: paidUsers.length,
      notPaidCount: notPaidUsers.length,
    });
  } catch (error) {
    res.status(error.statusCode || StatusCodes.INTERNAL_SERVER_ERROR).send(error.message || error);
  }
};

const showAllUser = async (req, res) => {
  const user = await User.find({});
  res.status(StatusCodes.OK).json({
    user,
    count: user.length,
  });
};

const showSingleUser = async (req, res) => {
  const {
    params: { id: userid },
  } = req;

  const user = await User.findOne({ _id: userid });

  const userData = extractUserData(user);
    
  res.status(StatusCodes.OK).json({
    userData,
  });
};

const extractUserData = (user) => {
  const userData = Object.fromEntries(
    Object.entries(user.toObject())
      .filter(([key]) => key !== "password") // Exclude the "password" field
      .filter(([key, value]) => value !== undefined)
  );
  
  return userData;
}

const regAsAffiliate = async (req, res) => {

  try {
  const userid = req.user.userid

    if (req.user.affiliateUserName) {
      throw new BadRequestError("You have already registered as an affiliate")
    }


    const username =  req.body.affiliateUserName
    

    const checkUsername = await User.findOne({affiliateUserName:username})
    

    if (checkUsername) {
      throw new BadRequestError("Username already exists")
    }

  //generate referral code
  const genRefCode = shortid.generate();
  
  const updateStatus = await User.updateOne(
    { _id: userid },
    {affiliateUserName:username, myRefCode:genRefCode},
    {
      runValidators: true,
    }
  );

  if (updateStatus.nModified == 0) {
    throw new NotFoundError('Request could not be processed');
  }

  res.status(StatusCodes.OK).json({ affiliateUserName:username, myRefCode:genRefCode});
  } catch (error) {
    console.log(error)
    res.status(StatusCodes.BAD_REQUEST).json(error.message)
  }
}

const showAllAffiliates = async (req, res) => {
  const user = await User.find({affiliateUserName:{$ne:null}});
  res.status(StatusCodes.OK).json({
    user,
    count: user.length,
  });
};

const calculateShareCapital = async (req, res) => {
 try {
  const factorial = 83.3333;
  const { houseAmount, spread } = req.body;
  let result;
  const email = req.user.email

//Spread Conditional Logic
if (spread === 1) {
  result = 0.6 * houseAmount;
} else if (spread === 2) {
  result = 0.555000 * houseAmount;
} else if (spread === 3) {
  result = 0.513375 * houseAmount;
} else if (spread === 4) {
  result = 0.474872 * houseAmount;
} else if (spread === 5) {
  result = 0.439256 * houseAmount;
} else if (spread === 6) {
  result = 0.406312 * houseAmount;
} else if (spread === 7) {
  result = 0.375839 * houseAmount;
} else if (spread === 8) {
  result = 0.347651 * houseAmount;
} else if (spread === 9) {
  result = 0.321577 * houseAmount;
} else if (spread === 10) {
  result = 0.297459 * houseAmount;
} else if (spread === 11) {
    result =  0.275150 * houseAmount;
}  else if (spread === 12) {
    result = 0.254513 * houseAmount;
}  else if (spread === 13) {
    result = 0.235425 * houseAmount;
}  else if (spread === 14) {
    result = 0.217768 * houseAmount;
}  else if (spread === 15) {
    result = 0.201435 * houseAmount;
}  else if (spread === 16) {
    result =  0.186327 * houseAmount;
}  else if (spread === 17) {
    result = 0.172352 * houseAmount;
}  else if (spread === 18) {
    result =  0.159426 * houseAmount;
}  else if (spread === 19) {
    result =  0.147469 * houseAmount;
}  else if (spread === 20) {
    result = 0.136408  * houseAmount;
}  else if (spread === 21) {
    result = 0.126177  * houseAmount;
}  else if (spread === 22) {
    result =  0.116714 * houseAmount;
}  else if (spread === 23) {
    result =  0.107960 * houseAmount;
}  else if (spread === 24) {
    result = 0.0932363  * houseAmount;
}  else if (spread === 25) {
    result = 0.0862436 * houseAmount;
}  else if (spread === 26) {
    result = 0.0797753  * houseAmount;
}  else if (spread === 27) {
    result = 0.0737921 * houseAmount;
}  else if (spread === 28) {
    result = 0.0682577  * houseAmount;
}  else if (spread === 29) {
    result = 0.0631384 * houseAmount;
} else if (spread === 30) {
    result = 0.0584030 * houseAmount;
} else {
     throw new BadRequestError("Something went wrong, check your Input")
  }

  result = Math.round(result)
  
  const monthlySpread = spread * 12;
  const houseBalance = houseAmount - result
  const monthlyHousePayment = Math.round(houseBalance / monthlySpread);

  updateOperations = {
    $set: {monthlyHousePaymentDub:monthlyHousePayment, houseAmountDub: houseAmount, shareCapitalLeft:result, spread:spread}
}

     await User.updateOne({email: email }, updateOperations
    )

  res.status(StatusCodes.OK).json({
    shareCapital: result,
    monthlyHousePayment: monthlyHousePayment

  });
 } catch (error) {

   res.status(StatusCodes.BAD_REQUEST).json(error.message)
 }
}



const editUserUnstructured = async (req, res) => {
  try {
    const {
      params: { id: userid },
      body: changes, // Destructure the changes directly from the req.body
    } = req;

    const result = await User.updateOne(
      { _id: userid },
      { $set: changes }, // Use $set to update the specified fields
      { runValidators: true }
    );

    if (result.nModified === 0) {
      throw new NotFoundError("Error making changes");
    }

    res.status(StatusCodes.OK).json({ msg: "Change has been successfully made" });
  } catch (error) {
    res.status(StatusCodes.BAD_REQUEST).json({ msg: error.message });
  }
};

const reqWithdrawal = async (req, res) => {
  const { userid, name, bank, accountNumber, balance } = req.user;
  const { amount } = req.body;

  if (amount > balance) {
    throw new BadRequestError("You do not have that much money in your available balance");
  }

  if (amount < 1000) {
    throw new BadRequestError("Withdrawals must be more than #1000");
  }


  const withdrawalReqData = {
    ...req.body,
    createdBy: userid,
    name,
    bank,
    accountNumber,
    createdAt: Date.now(),
  };

  const withdrawalReq = await Withdrawal.create(withdrawalReqData);

  const updatedBalance = balance - amount;

  await User.updateOne(
    { _id: userid },
    { $set: { balance: updatedBalance } }
  );

  res.status(StatusCodes.OK).json({ withdrawalReq });
};


const approveOrDeclineReq = async (req, res) => {
  const {params: {id: withdrawalId}} = req
  const withdrawal = await Withdrawal.findOneAndUpdate({_id: withdrawalId}, req.body, {
      new: true,
      runValidators: true,
  })

  if (!withdrawal) {
    throw new NotFoundError(`No user with id of ${withdrawalId}`);
  }
  
  if (req.body === 'approved') {
    req.user.withdrawn += withdrawal.amount
    
    const updateData = {
      withdrawn: req.user.withdrawn,
    }


    const result = await User.updateOne({ createdBy: withdrawalId }, { $set: updateData });

    if (result.nModified == 0) {
      throw new BadRequestError('User cannot be updated contact support')
    }
  }
 
  res.status(StatusCodes.OK).json({msg: `Withdrawal has been changed to ${req.body.withdrawalStatus}`})
  }

const getAllWithdrawals = async (req, res) => {
      const withdrawals = await Withdrawal.find({withdrawalStatus:'approved'}).sort({createdAt:-1})
       
      res.status(StatusCodes.OK).json({
          withdrawals,
          count: withdrawals.length
      })
  }


const getAllPendingWithdrawals = async (req, res) => {
      const pending = await Withdrawal.find({withdrawalStatus:'pending'}).sort({createdAt:-1})
       
      res.status(StatusCodes.OK).json({
          pending,
          count: pending.length
      })
  }

  const calculateROI = async (req, res) => {
    try {
    let email = req.user.email
     const { amount, spread } = req.body;
     const annualRoi = amount * 0.3
    
     await User.updateOne(
      { email: email },
      { $set: { investSpread: spread } }
    );


     res.status(StatusCodes.OK).json({
       annualReturn: annualRoi,
       investmentAmount:amount,
   
     });
    } catch (error) {
   
      res.status(StatusCodes.BAD_REQUEST).json(error.message)
    }
   }
   
   const getAllMyWithdrawals = async (req, res) => {
    const id = req.user.userid
    const withdrawals = await Withdrawal.find({createdBy:id}).sort({createdAt: -1})
     
    res.status(StatusCodes.OK).json({
        withdrawals,
        count: withdrawals.length
    })
  }
  

  const checkLoanEligibility = async (req, res) => {
    const dateJoined = new Date(req.user.dateRegistered);
    const today = new Date();
    
    // Calculate the difference in months
    const monthsDiff = (today.getFullYear() - dateJoined.getFullYear()) * 12 +
                      (today.getMonth() - dateJoined.getMonth());
    
    if (monthsDiff >= 3) {
      // The user is eligible for the loan
      res.status(200).json({ message: "Loan eligibility confirmed." });
    } else {
      // The user is not eligible for the loan
      throw new BadRequestError("To qualify for a loan you need to have been part of the co-operative for at least 6 months");
    }
  }

  const uploadImage = async (req, res) => {
     
    try {
      const {
        userid
      } = req.user

    
      //Get the URL of the uploaded file
      const fileUrl = `https://${process.env.S3_BUCKET_NAME}.s3.amazonaws.com/${req.file.key}`;
     
    
      // Save the file URL to the user object in the database
      req.body.imageLink = fileUrl;
    
      const updateStatus = await User.updateOne(
        { _id: userid },
        {
          imageLink: req.body.imageLink,
        },
        {
          runValidators: true,
        }
      );
    
      if (updateStatus.nModified == 0) {
        throw new NotFoundError(`No user with id of ${userid}`);
      }
    
      res.status(StatusCodes.OK).json({ msg: "Image Uploaded Successfully" });
    } catch(error) {
      console.log(error)
    }
      
     
    }
  
   
   

module.exports = {
  editUser, 
  showSingleUser,
  showUserByStatus,
  showAllUser,
  regAsAffiliate,
  showAllAffiliates,
  calculateShareCapital,
  editUserUnstructured,
  reqWithdrawal,
  approveOrDeclineReq,
  getAllWithdrawals,
  getAllPendingWithdrawals,
  calculateROI,
  getAllMyWithdrawals,
  checkLoanEligibility,
  uploadImage                                                                                                                                                          
};
