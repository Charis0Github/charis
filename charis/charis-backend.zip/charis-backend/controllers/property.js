const User = require("../models/User");
const Property = require("../models/Property");
const { StatusCodes } = require("http-status-codes");
const { BadRequestError, UnauthenticatedError, NotFoundError } = require("../errors");
const jwt = require("jsonwebtoken");


const removeProperty = async (req, res) => {
  const {params: {id: propertyId}} = req
  const property = await Property.findOneAndDelete({
   _id: propertyId
  }) 
  
  

  res.status(StatusCodes.OK).json({
   msg: `${property.name} has been deleted successfully`,
   property_left:property,
   count:property.length
})
}


const editProperty = async (req, res) => {
  try {
    const {
      params: { id: propertyId },
    } = req;
  
    const changes = req.body

    const updateStatus = await Property.updateOne(
      { _id: propertyId },
      {
        $set: changes,
      },
      {
        runValidators: true,
      }
    );
  
    if (updateStatus.nModified == 0) {
      throw new NotFoundError(`No property with id of ${propertyId}`);
    }
  
    res.status(StatusCodes.OK).json({ msg: "Change has been Successfully made" });
  } catch(error) {
      res.status(error.statusCode).send(error.message)
  }

}

const createProperty = async (req, res) => {
  try {
       
    //Get the URL of the uploaded file
    
    const fileUrl = `https://${process.env.S3_BUCKET_NAME}.s3.amazonaws.com/${req.file.key}`;
  
    // Save the file URL to the user object in the database
    req.body.imageLink = fileUrl;
    
    const property = await Property.create(req.body);
  
    res.status(StatusCodes.OK).json({property})
  } catch(error) {
     res.send(error)
  }

}

const showAllProperties = async (req, res) => {
  const properties = await Property.find({status:'pending'});
  res.status(StatusCodes.OK).json({
    properties,
    count: properties.length,
  });
};

const showApprovedProperties  = async (req, res) => {
  const properties = await Property.find({status:'approved'});
  res.status(StatusCodes.OK).json({
    properties,
    count: properties.length,
  });
};

const showSingleProperty = async (req, res) => {
  const {
    params: { id: propertyId },
  } = req;
  const property = await Property.findOne({ _id: propertyId });
  res.status(StatusCodes.OK).json({
    property,
  });
};

module.exports = {
  showAllProperties,
  showApprovedProperties,
  showSingleProperty,
  createProperty,
  editProperty,
  removeProperty};
