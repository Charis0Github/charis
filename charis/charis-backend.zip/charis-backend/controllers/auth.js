const User = require("../models/User");
const sendEmail = require("../middleware/mailer");
const PaymentRecord = require("../models/PaymentRecords");
const { StatusCodes } = require("http-status-codes");
const { BadRequestError, UnauthenticatedError } = require("../errors");
const jwt = require("jsonwebtoken");
const nodemailer = require("nodemailer");
const axios = require("axios");

const registerUser = async (req, res) => {
  try {
    if (req.body.uniqueKey === 1212) {
      req.body.role = "admin";
    }

    //REFERRE LOGIC
    if (req.body.referralCode) {
      const referralCode = req.body.referralCode;

      req.body.referee = referralCode;

      // Increment unpaidRefs
      const incResult = await User.updateOne(
        { myRefCode: referralCode },
        { $inc: { unpaidRefs: 1 } }
      );

      const reff = await User.findOne({ myRefCode: referralCode });

      // Check if any document was modified
      if (incResult.nModified === 0) {
        return res
          .status(StatusCodes.BAD_REQUEST)
          .json({ msg: "No user with that referral code" });
      }

      req.body.createdAt = Date.now();
      const user = await User.create({ ...req.body });
      const token = user.createJWT();

      //mailers
      sendEmail(
        user.email,
        "Welcome To Charis Advantage LGi",
        `
      <style>
        body {
          font-family: 'Arial', sans-serif;
          background-color: #f5f5f5;
          text-align: center;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 10px;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
          color: #333333;
        }
        p {
          color: #666666;
          font-size: 16px;
        }
        .cta-button {
          display: inline-block;
          padding: 10px 20px;
          margin-top: 20px;
          background-color: #4CAF50;
          color: #ffffff;
          text-decoration: none;
          border-radius: 5px;
          font-weight: bold;
        }
      </style>
      <div class="container">
        <h1>Welcome to Charis Advantage LGi</h1>
        <p>Congratulations on your registration to the Charis Website. We are thrilled to have you and guide you through your journey.</p>
        <p>Click the button below to get started:</p>
        <a class="cta-button" href="https://your-charis-website.com/get-started">Get Started</a>
      </div>
      <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
      <script src="https://cdn.jsdelivr.net/confetti.js/0.0.21/confetti.min.js"></script>
      <script>
        particlesJS('body', {
          particles: {
            number: { value: 50 },
            color: { value: '#4CAF50' },
            shape: { type: 'circle' },
            opacity: { value: 0.8, random: true },
            size: { value: 5, random: true },
            line_linked: { enable: false }
          },
          interactivity: { events: { onhover: { enable: true, mode: 'repulse' } } }
        });
        confetti();
      </script>
    `,
        (error, info) => {
          if (error) {
            console.error("Error sending email:", error);
          } else {
            console.log("Email sent:", info.response);
          }
        }
      );

      //API RESPONSE
      res
        .status(StatusCodes.CREATED)
        .json({
          user: {
            name: user.name,
            userId: user._id,
            role: user.role,
            email: user.email,
            status: user.status,
            createdAt: user.createdAt,
            phoneNumber: user.phoneNumber,
          },
          token,
        });
    } else {
      return res
        .status(StatusCodes.BAD_REQUEST)
        .json({ msg: "You need to fill in the referral Code" });
    }
  } catch (error) {
    console.log(error);
    if (error.name === "MongoError") {
      res
        .status(StatusCodes.BAD_REQUEST)
        .json({ msg: "Email has been used. Please try another" });
    } else {
      res
        .status(StatusCodes.INTERNAL_SERVER_ERROR)
        .json({ msg: "An unexpected error occurred. Try again" });
    }
  }
};

const login = async (req, res) => {
  try {
    const { password, email } = req.body;

    if (!email || !password) {
      throw new BadRequestError("Please provide your email and password");
    }

    const user = await User.findOne({ email });

    if (!user) {
      throw new UnauthenticatedError("Invalid email or password");
    }

    const isPasswordValid = await user.comparePassword(password);

    if (!isPasswordValid) {
      throw new UnauthenticatedError("Invalid email or password");
    }

    const token = user.createJWT();

    res.status(StatusCodes.OK).json({ _id: user._id, token });
  } catch (error) {
    res.status(StatusCodes.BAD_REQUEST).json({ msg: error.message });
  }
};

const forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      throw new UnauthenticatedError("Please provide your email");
    }

    const user = await User.findOne({ email });

    if (!user) {
      throw new UnauthenticatedError("Invalid Email");
    }

    const resetToken = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });

    user.resetPasswordToken = resetToken;
    user.resetPasswordExpire = Date.now() + 3600000; // 1 hour
    await user.save();

    const transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 465,
      secure: true,
      auth: {
        user: process.env.EMAIL_USERNAME,
        pass: process.env.EMAIL_PASSWORD,
      },
    });

    const mailOptions = {
      from: "foresightagencies@gmail.com",
      to: user.email,
      subject: "Password Reset Request",
      html: `
            <p>You are receiving this email because you (or someone else) has requested a password reset for your account.</p>
            <p>Please click the following link to reset your password:</p>
            <a href="https://charis.org/auth/reset-password?token=${resetToken}">Reset Password</a
            <p>If you did not request a password reset, please ignore this email.</p>
          `,
    };

    await transporter.sendMail(mailOptions);

    res.status(200).json({ message: "Password reset link sent to your email" });
  } catch (error) {
    //res.status(error.statusCode).send(error)
    res.status(400).json({ message: error.message });
  }
};

// Reset password action
const resetPassword = async (req, res) => {
  try {
    const { newPassword, resetCode } = req.body;

    // Find the user with the given reset token and within the expiration time
    const user = await User.findOne({
      resetPasswordToken: resetCode,
      resetPasswordExpires: {
        $gt: Date.now(),
      },
    });

    if (!user) {
      throw new Error("Invalid reset token or token expired");
    }

    // Password reset logic
    const hashedPassword = await user.hashPassword(newPassword);
    user.password = hashedPassword;

    user.resetPasswordToken = null;
    user.resetPasswordExpires = null;

    // Instead of user.save(), use updateOne to update only the necessary fields
    const result = await User.updateOne(
      { _id: user._id },
      {
        $set: {
          password: user.password,
          resetPasswordToken: user.resetPasswordToken,
          resetPasswordExpires: user.resetPasswordExpires,
        },
      }
    );

    if (result.nModified !== 1) {
      // If the update did not modify exactly one document, consider it an error
      throw new Error("Password update failed");
    }

    res.status(200).json({
      msg: "Password reset successfully",
    });
  } catch (error) {
    if (error.name === "MongoError" && error.code === 11000) {
      // Handle duplicate key error (e.g., unique constraint violation)
      res.status(400).json({
        msg: "Database error: Duplicate key",
      });
    } else {
      // Handle other errors
      res.status(400).json({
        msg: `Error: ${error.message}`,
      });
    }
  }
};

const getBanks = async (req, res) => {
  const url = "https://api.flutterwave.com/v3/banks/NG";
  const headers = {
    Authorization: `Bearer ${process.env.SECRET_KEY}`,
    "Content-Type": "application/json",
  };

  try {
    const response = await axios.get(url, { headers });
    const banks = response.data.data;
    let bankNames = banks.map((bank) => bank.name);
    bankNames.sort(); // Sort the bank names alphabetically
    res.status(StatusCodes.OK).json({ bankNames });
  } catch (error) {
    console.error("An error occurred:", error.message);
  }
};

module.exports = {
  login,
  registerUser,
  getBanks,
  forgotPassword,
  resetPassword,
};
