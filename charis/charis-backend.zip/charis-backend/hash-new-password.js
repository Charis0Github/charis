const bcrypt = require("bcryptjs");
bcrypt.genSalt(10).then((salt) => {
  bcrypt.hash("efone987@gmail.com", salt).then((password) => {
    console.log({ password });
  });
});

//  node hash-new-password.js
